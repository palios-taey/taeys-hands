# Consultation V2 Review and Replacement Plan

Branch target: `consultation-v2-isolated-drivers`

## What is broken in the current Consultation path

1. The current codebase still routes core consultation steps through shared handlers. Model and mode selection, file attachment, send, completion monitoring, and extraction are each implemented as cross-platform helpers. That means tuning one platform changes the behavior surface for every other platform.
2. `core/config.py` is explicitly a single shared YAML loader used everywhere. That is convenient for reuse, but it also encourages workflow code to reach into one shared configuration layer instead of treating each platform as its own automation contract.
3. The current `core/mode_select.py` intentionally uses one universal selection flow for all platforms. That design choice is the opposite of the isolation requirement for Consultation.
4. `tools/send.py` still follows a generic “find an editable field, paste, press Enter, then poll the URL” path. That is not platform-owned send logic.
5. `monitor/central.py` is a shared completion detector. It monitors stop button visibility and content stability for every platform from one policy engine.
6. Several YAMLs are good at filtering noise, but they are not yet complete contracts for consultation execution. Important elements for exact model or tool selection are still missing in some platforms, and at least one test is stale relative to the YAML defaults.

## What this bundle changes

This bundle introduces a new `consultation_v2/` package with these rules:

- Every chat platform gets its own driver file.
- Every driver owns its own implementation for the eight consultation steps:
  1. model / mode / tool selection
  2. attachment
  3. prompt entry
  4. send
  5. stop-button monitoring
  6. primary extraction
  7. additional extraction
  8. Neo4j storage
- The only shared code left is low-level plumbing: YAML loading, AT-SPI scanning, exact element matching, keyboard/mouse primitives, clipboard access, and result dataclasses.
- Consultation V2 does **not** import or reuse `tools.attach`, `tools.dropdown`, `tools.send`, `tools.extract`, `core.mode_select`, or `monitor.central`.
- Consultation V2 uses a separate YAML contract under `consultation_v2/platforms/` so the new flow can evolve without breaking Bots or the existing MCP tools.

## Migration posture

This bundle is intentionally additive. It does not rewrite the existing MCP server path. It gives you a branch-ready consultation runner that can be validated in parallel and swapped in only after platform checks are clean.

## Remaining open items

- Grok’s send control is still best handled by Return plus AT-SPI validation because the current mapped tree does not expose a stable exact send button name in the source snapshot I reviewed.
- Claude and Gemini artifact/report export flows still need one live pass per platform to fill any remaining exact export-menu labels if you want step 7 to be fully exhaustive for every artifact shape.
- Once this lands in a real git clone, I would wire the new runner behind a feature flag and then delete the old consultation orchestration after side-by-side validation.
