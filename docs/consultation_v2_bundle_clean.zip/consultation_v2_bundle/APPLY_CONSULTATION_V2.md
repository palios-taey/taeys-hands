# Apply Consultation V2 Bundle

Suggested branch:

```bash
git checkout -b consultation-v2-isolated-drivers
```

Apply the patch from the repository root:

```bash
git apply /path/to/consultation_v2_bundle.patch
```

Or copy the bundle contents into the repository root so these new paths exist:

- `CONSULTATION_V2_REVIEW.md`
- `APPLY_CONSULTATION_V2.md`
- `consultation_v2/`
- `scripts/consultation_v2.py`
- `tests/test_consultation_v2_contract.py`
- `tests/test_consultation_v2_isolation.py`

Run the isolated Consultation V2 tests:

```bash
pytest -q tests/test_consultation_v2_contract.py tests/test_consultation_v2_isolation.py
```

Run the new Consultation V2 entrypoint:

```bash
python scripts/consultation_v2.py \
  --platform claude \
  --message "test message" \
  --attach /absolute/path/to/file.txt \
  --mode extended_thinking \
  --tool research \
  --output /tmp/consultation_result.json
```

Migration note:

This bundle is additive. It does not replace the existing consultation path until you wire it in.
