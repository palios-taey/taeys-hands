/**
 * Platform Bridge Factory
 * 
 * Purpose: Detect OS and create appropriate automation bridge
 * Dependencies: os module, MacOSBridge, LinuxBridge
 * Exports: createBridge(), detectPlatform()
 * 
 * @module core/platform/bridge-factory
 */

import os from 'os';
import { MacOSBridge } from './macos-bridge.js';
import { LinuxBridge } from './linux-bridge.js';

/**
 * Detect the current operating system platform
 * @returns {'macos' | 'linux' | 'windows' | 'unknown'}
 */
export function detectPlatform() {
  const platform = os.platform();
  
  switch (platform) {
    case 'darwin':
      return 'macos';
    case 'linux':
      return 'linux';
    case 'win32':
      return 'windows';
    default:
      return 'unknown';
  }
}

/**
 * Create a platform-specific automation bridge
 * 
 * @param {Object} options - Bridge configuration options
 * @param {string} [options.browser='Google Chrome'] - Browser name for automation
 * @returns {MacOSBridge | LinuxBridge} Platform-appropriate bridge instance
 * @throws {Error} If platform is unsupported
 * 
 * @example
 * const bridge = createBridge({ browser: 'Google Chrome' });
 * await bridge.type('Hello, World!');
 */
export function createBridge(options = {}) {
  const platform = detectPlatform();
  const browserName = options.browser || 'Google Chrome';
  
  switch (platform) {
    case 'macos':
      return new MacOSBridge({ browser: browserName });
    
    case 'linux':
      return new LinuxBridge({ browser: browserName });
    
    case 'windows':
      throw new Error(
        'Windows is not yet supported. ' +
        'Use WSL2 with Linux bridge or switch to macOS.'
      );
    
    default:
      throw new Error(
        `Unknown platform: ${os.platform()}. ` +
        'Supported platforms: macOS (darwin), Linux'
      );
  }
}

/**
 * Get platform-specific timing multiplier
 * Slower systems get longer waits for reliability
 * 
 * @returns {number} Multiplier (1.0 = fast, 2.0 = slow)
 */
export function getTimingMultiplier() {
  const cpuCount = os.cpus().length;
  const totalMemGB = os.totalmem() / (1024 ** 3);
  
  // Fast system: 8+ cores, 16GB+ RAM
  if (cpuCount >= 8 && totalMemGB >= 16) {
    return 1.0;
  }
  
  // Medium system: 4+ cores, 8GB+ RAM
  if (cpuCount >= 4 && totalMemGB >= 8) {
    return 1.5;
  }
  
  // Slow system
  return 2.0;
}

/**
 * Standard timing constants (in milliseconds)
 * Multiply by getTimingMultiplier() for slower systems
 */
export const TIMING = {
  TAB_FOCUS: 200,
  APP_FOCUS: 500,
  MENU_RENDER: 800,
  FILE_DIALOG_SPAWN: 1500,
  APPLESCRIPT_EXEC: 500,
  TYPING_BUFFER: 300,
  FINDER_NAVIGATE: 1000,
  FILE_UPLOAD_PROCESS: 1500,
  NETWORK_SEND: 1000,
  STABILITY_POLL: 2000,
  SCREENSHOT_WAIT: 500,
  CMD_SHIFT_G_WAIT: 800,
  FILENAME_TYPE_WAIT: 300,
  ENTER_WAIT: 1000
};

/**
 * Get adjusted timing value based on system performance
 * 
 * @param {string} key - Timing constant key from TIMING
 * @returns {number} Adjusted timing in milliseconds
 */
export function getTiming(key) {
  const multiplier = getTimingMultiplier();
  const baseValue = TIMING[key];
  
  if (baseValue === undefined) {
    throw new Error(`Unknown timing key: ${key}`);
  }
  
  return Math.round(baseValue * multiplier);
}
